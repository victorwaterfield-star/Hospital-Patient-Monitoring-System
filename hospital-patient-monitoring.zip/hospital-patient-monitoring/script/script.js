// Example: simple alert on page load
window.onload = () => {
  console.log("Hospital Patient Monitoring System Loaded");
};
