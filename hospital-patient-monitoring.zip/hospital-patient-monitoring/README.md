# 🏥 Hospital Patient Monitoring System

A simple front-end project built with **HTML**, **CSS**, and a touch of **JavaScript** to simulate a hospital dashboard for monitoring patient information.

---

## 📋 Project Overview

This project provides a clean and responsive interface for hospital staff to view and manage patient data such as vital signs, health status, and condition summaries. It is a beginner-friendly project that helps practice layout design, table formatting, and deployment with GitHub Pages.

---

## ✨ Features

- 📊 **Dashboard Overview** — Displays summary cards for total, admitted, discharged, and critical patients.  
- 👨‍⚕️ **Patient List Page** — Table layout with patient details (name, age, condition, vitals, status).  
- 🎨 **Responsive Design** — Works well on both desktop and mobile screens.  
- 🟢 **Status Indicators** — Color-coded badges for Stable, Under Observation, and Critical patients.  
- 🧩 **Reusable Layout** — Shared header, footer, and navigation across all pages.  

---

## 🧠 Technologies Used

- **HTML5** — For page structure.  
- **CSS3** — For styling and layout.  
- **JavaScript (optional)** — For simple interactivity (e.g., alerts, search, dark mode).  

---

## 🚀 Deployment (GitHub Pages)

Follow these steps to publish your project:

1. Create a new repository on GitHub (e.g., `hospital-patient-monitoring`).
2. Upload or push all project files (`index.html`, `patients.html`, `style/`, `script/`, and `images/`).
3. Go to **Settings → Pages**.
4. Under **Branch**, select `main` and folder `/ (root)`.
5. Click **Save**.  
   After a few minutes, your site will be live at:  
   **https://your-username.github.io/hospital-patient-monitoring/**

---

## 📁 Folder Structure

